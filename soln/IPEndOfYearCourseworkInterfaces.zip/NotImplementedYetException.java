
/**
 *
 * @author Steven Bradley
 * @version 0.1
 * 
 */
public class NotImplementedYetException extends RuntimeException
{
    public NotImplementedYetException(String message){
        super(message);
    }
}
