
/**
 *
 * @author Steven Bradley
 * @version 0.1
 * 
 */
public class QuitGameException extends Exception
{
    public QuitGameException(String message){
        super(message);
    }
}
