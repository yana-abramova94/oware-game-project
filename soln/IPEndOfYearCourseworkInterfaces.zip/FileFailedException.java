
/**
 *
 * @author Steven Bradley
 * @version 0.1
 * 
 */
public class FileFailedException extends Exception
{
    public FileFailedException(String message){
        super(message);
    }
}
